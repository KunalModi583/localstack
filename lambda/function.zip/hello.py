def lambda_handler(event, context):
    return { 
        'message' : "from localstack lambda"
    }