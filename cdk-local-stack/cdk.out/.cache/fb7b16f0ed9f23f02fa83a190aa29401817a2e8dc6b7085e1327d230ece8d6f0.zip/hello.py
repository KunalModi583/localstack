def handler(event, context):
    return { 
        'message' : "from localstack lambda"
    }